$ErrorActionPreference = 'Stop'
$project = Join-Path $HOME 'GridHive-Anthill'
New-Item -ItemType Directory -Force -Path $project | Out-Null
Set-Location $project
@'
streamlit>=1.40,<2
pandas>=2.2,<3
plotly>=5.24,<7
'@ | Set-Content -Encoding UTF8 requirements.txt
@'
services:
  - type: web
    name: gridhive-anthill
    runtime: python
    plan: free
    buildCommand: pip install -r requirements.txt
    startCommand: streamlit run app.py --server.address 0.0.0.0 --server.port $PORT --server.headless true
    envVars:
      - key: PYTHON_VERSION
        value: 3.12.8
'@ | Set-Content -Encoding UTF8 render.yaml
# Download the companion app.py from the supplied ZIP and put it in this directory.
if (!(Test-Path app.py)) { throw 'Put app.py from GridHive-Anthill.zip in this folder before running setup-gridhive.ps1' }
py -3 -m venv .venv
& .\.venv\Scripts\python.exe -m pip install --upgrade pip
& .\.venv\Scripts\python.exe -m pip install -r requirements.txt
& .\.venv\Scripts\python.exe -m streamlit run app.py
