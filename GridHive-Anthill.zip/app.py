import streamlit as st
import pandas as pd
import plotly.express as px

st.set_page_config(page_title='the Anthill | GridHive',page_icon='🐞',layout='wide')
st.title('🐞 the Anthill')
st.caption('GridHive | Hurricane resilience command center — DEMONSTRATION DATA ONLY')
assets=pd.DataFrame([
['Miami Substation',25.7617,-80.1918,90,4200,100,70,'Substation'],
['Doral Feeder',25.8195,-80.3553,65,1700,70,60,'Feeder'],
['Homestead Transformer',25.4687,-80.4776,80,900,85,80,'Transformer'],
['Fort Lauderdale Feeder',26.1224,-80.1373,45,2600,60,45,'Feeder'],
['Key Largo Substation',25.0865,-80.4473,85,2100,95,90,'Substation'],
['Westchester Transformer',25.747,-80.317,35,350,30,30,'Transformer']],
columns=['Asset','lat','lon','Severity','Customers','Criticality','Urgency','Type'])
if 'inspections' not in st.session_state: st.session_state.inspections=[]
st.sidebar.header('Storm scenario')
storm=st.sidebar.select_slider('Simulated storm severity',options=['Normal','Tropical storm','Category 1','Category 3','Category 5'],value='Category 3')
boost={'Normal':-35,'Tropical storm':-15,'Category 1':0,'Category 3':10,'Category 5':20}[storm]
assets['Severity']=(assets['Severity']+boost).clip(0,100)
assets['CustomerScore']=assets['Customers']/assets['Customers'].max()*100
assets['Priority']=(.35*assets['Severity']+.30*assets['CustomerScore']+.20*assets['Criticality']+.15*assets['Urgency']).round(1)
assets['Risk']=pd.cut(assets['Priority'],bins=[-1,40,70,101],labels=['Low','Elevated','Critical'])
assets=assets.sort_values('Priority',ascending=False)
a,b,c=st.columns(3)
a.metric('Assets monitored',len(assets));b.metric('Critical assets',int((assets['Risk']=='Critical').sum()));c.metric('Customers potentially affected',f"{assets['Customers'].sum():,}")
tab1,tab2,tab3,tab4=st.tabs(['🗺️ Risk map','📋 Restoration queue','📷 Robot inspection','💵 Economic impact'])
with tab1:
 st.subheader('Florida grid risk — simulated locations')
 fig=px.scatter_map(assets,lat='lat',lon='lon',color='Risk',size='Customers',hover_name='Asset',hover_data=['Priority','Severity','Type'],zoom=7,height=510,color_discrete_map={'Low':'#20a87b','Elevated':'#e9a43b','Critical':'#dd4756'},map_style='open-street-map')
 st.plotly_chart(fig,use_container_width=True)
with tab2:
 st.subheader('Explainable restoration priorities')
 st.dataframe(assets[['Asset','Type','Severity','Customers','Criticality','Urgency','Priority','Risk']],hide_index=True,use_container_width=True)
 chosen=st.selectbox('Inspect priority calculation',assets['Asset'])
 item=assets.loc[assets['Asset']==chosen].iloc[0]
 st.info(f"{chosen}: score {item['Priority']}/100 = 35% damage severity + 30% normalized customers affected + 20% critical facility importance + 15% urgency. This is a demonstration model, not a validated utility algorithm.")
with tab3:
 st.subheader('Inspection intake')
 with st.form('inspection'):
  target=st.selectbox('Grid asset',assets['Asset'])
  observation=st.text_area('Observed damage / notes',placeholder='Example: fallen tree near feeder, pending human confirmation')
  photo=st.file_uploader('Optional inspection photo',type=['png','jpg','jpeg'])
  submit=st.form_submit_button('Add inspection record')
 if submit:
  st.session_state.inspections.append({'Asset':target,'Notes':observation or 'No notes provided','Image attached':bool(photo)})
  st.success('Inspection recorded for this session (not permanently saved).')
 if st.session_state.inspections: st.dataframe(pd.DataFrame(st.session_state.inspections),hide_index=True,use_container_width=True)
 if photo: st.image(photo,caption='Uploaded image — no automated damage verification',width=440)
with tab4:
 st.subheader('Illustrative outage impact')
 hours=st.slider('Assumed outage duration (hours)',1,72,12)
 cost=st.number_input('Illustrative cost per customer-hour ($)',min_value=0.,value=8.,step=1.)
 customer_hours=int(assets['Customers'].sum())*hours
 st.metric('Potential customer outage-hours',f'{customer_hours:,}')
 st.metric('Scenario economic impact (assumption-based)',f'${customer_hours*cost:,.0f}')
 st.caption('This is not a validated estimate of utility costs or avoided damages.')
st.divider()
st.caption('GridHive semifinals prototype | simulated risk, no real grid monitoring or autonomous control')
